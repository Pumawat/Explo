
#ifndef RPY_AR_H
#define RPY_AR_H

#include <R.h>
#include <Python.h>

static PyObject* 
array_struct_get(PySexpObject *self);

#endif /* !RPY_AR_H */
